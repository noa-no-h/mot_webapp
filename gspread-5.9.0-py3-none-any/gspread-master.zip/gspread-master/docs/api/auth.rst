Auth
====

.. automodule:: gspread.auth
   :members:
