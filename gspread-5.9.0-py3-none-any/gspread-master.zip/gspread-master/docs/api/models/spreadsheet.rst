Spreadsheet
===========

.. autoclass:: gspread.spreadsheet.Spreadsheet
   :members:
