Client
======

.. autoclass:: gspread.Client
   :members:

.. autoclass:: gspread.client.BackoffClient
   :members:
