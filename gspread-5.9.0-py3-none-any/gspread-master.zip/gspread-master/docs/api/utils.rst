Utils
=====

.. autonamedtuple:: gspread.utils.Dimension
.. autonamedtuple:: gspread.utils.DateTimeOption
.. autonamedtuple:: gspread.utils.ExportFormat
.. autonamedtuple:: gspread.utils.MimeType
.. autonamedtuple:: gspread.utils.PasteOrientation
.. autonamedtuple:: gspread.utils.PasteType
.. autonamedtuple:: gspread.utils.ValueInputOption
.. autonamedtuple:: gspread.utils.ValueRenderOption

.. automodule:: gspread.utils
   :members:
   :undoc-members:
